import mysql.connector

bookcode=input("Enter the Book Code : ")


con=mysql.connector.connect(host="b9gfy5kf7ge1gqnyqane-mysql.services.clever-cloud.com", user="unpqwxlric7csza5", password="5IAOjIQhuSHEy9X2vTJL", database="b9gfy5kf7ge1gqnyqane")
curs=con.cursor()

curs.execute("select bookcode,bookname,category,author,publication,edition,price from books where bookcode='%s'" %bookcode)
rec=curs.fetchone()


try:

  print("Book Code : %s" %rec[0])
  print("Book Name : %s" %rec[1])
  print("Category : %s" %rec[2])
  print("Author : %s" %rec[3])
  print("Publication : %s" %rec[4])
  print("Edition: %d" %rec[5])
  print("Price : %d" %rec[6])


  print("************************************************")
  Que=input("Do you want to delete this book ? ")
  if Que=='yes':
    curs.execute("delete from books where bookcode='%s'" %bookcode)
    con.commit()
    print("Book is deleted")
  else:
      print("OK..")

except:
     print("Book does not exist")


con.close()
import mysql.connector

con=mysql.connector.connect(host="b9gfy5kf7ge1gqnyqane-mysql.services.clever-cloud.com", user="unpqwxlric7csza5", password="5IAOjIQhuSHEy9X2vTJL", database="b9gfy5kf7ge1gqnyqane")
curs=con.cursor()


category=input("Enter the Book Category : ")

curs.execute("select bookcode,bookname,author,publication,edition,price from books where category='%s'" %category)
data=curs.fetchall()


for rec in data:

  print("Book Code : %s" %rec[0])
  print("Book Name : %s" %rec[1])
  print("Author : %s" %rec[2])
  print("Publication : %s" %rec[3])
  print("Edition: %d" %rec[4])
  print("Price : %d" %rec[5])

con.close()
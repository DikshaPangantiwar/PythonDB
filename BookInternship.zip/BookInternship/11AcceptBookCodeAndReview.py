import mysql.connector

bookcode=input("Enter the Book Code : ")

con=mysql.connector.connect(host="b9gfy5kf7ge1gqnyqane-mysql.services.clever-cloud.com", user="unpqwxlric7csza5", password="5IAOjIQhuSHEy9X2vTJL", database="b9gfy5kf7ge1gqnyqane")
curs=con.cursor()

curs.execute("select bookcode from books where bookcode='%s'" %bookcode)
data=curs.fetchone()

try:
    if bookcode in data:
        rev=input("Write the Review : ")
        curs.execute("update books set review='%s' where bookcode='%s'" %(rev,bookcode))
        con.commit()
        print("Review is Submitted..")

except:
    print("BookCode does not exist!!")

con.close()
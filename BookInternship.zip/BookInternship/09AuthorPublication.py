import mysql.connector

author=input("Enter the Book Author : ")
publication=input("Enter the Book Publication : ")

con=mysql.connector.connect(host="b9gfy5kf7ge1gqnyqane-mysql.services.clever-cloud.com", user="unpqwxlric7csza5", password="5IAOjIQhuSHEy9X2vTJL", database="b9gfy5kf7ge1gqnyqane")
curs=con.cursor()

curs.execute("select * from books where author='%s' and publication='%s'" %(author,publication))
rec=curs.fetchone()

try:
    print("**********************")
    print("Book is : %s" %rec[1])
except:
    print("Book does not exist!!")

con.close()
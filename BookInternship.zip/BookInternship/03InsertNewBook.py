import mysql.connector as mycon

con=mycon.connect(host='b9gfy5kf7ge1gqnyqane-mysql.services.clever-cloud.com',user='unpqwxlric7csza5',password='5IAOjIQhuSHEy9X2vTJL',database='b9gfy5kf7ge1gqnyqane')
curs=con.cursor()


bookcode=input("Enter the Book Code : ")
bookname=input("Enter the Book Name : ")
category=input("Enter the Book Category : ")
author=input("Enter the Book Author : ")
publication=input("Enter the Book Publication : ")
edition=int(input("Enter the Book Edition : "))
price=int(input("Enter the Book Price : "))
review=input("Enter the Book Review : ")

curs.execute("insert into books values('%s','%s','%s','%s','%s',%d,%d,'%s')"  %(bookcode,bookname,category,author,publication,edition,price,review))
con.commit()

print("New Book Added Successfully..")

con.close()
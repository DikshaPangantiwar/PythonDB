import mysql.connector as mycon

con=mycon.connect(host='b9gfy5kf7ge1gqnyqane-mysql.services.clever-cloud.com',user='unpqwxlric7csza5',password='5IAOjIQhuSHEy9X2vTJL',database='b9gfy5kf7ge1gqnyqane')
curs=con.cursor()

curs.execute("select * from books")
data=curs.fetchall()

print(data)

con.close()
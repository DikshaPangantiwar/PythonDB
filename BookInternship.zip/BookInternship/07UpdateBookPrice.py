import mysql.connector

bookcode=input("Enter the Book Code : ")
price=int(input("Enter New Price : "))


con=mysql.connector.connect(host="b9gfy5kf7ge1gqnyqane-mysql.services.clever-cloud.com", user="unpqwxlric7csza5", password="5IAOjIQhuSHEy9X2vTJL", database="b9gfy5kf7ge1gqnyqane")
curs=con.cursor()

curs.execute("select bookcode from books where bookcode='%s'" %bookcode)
data=curs.fetchone()

try:
 if bookcode in data: 
     curs.execute("update books set price=%d where bookcode='%s';"  %(price,bookcode)) 
     con.commit()
     print(" Book Price Updated Successful...")

except:
     
      print("Book Does Not Exist!!")
    

con.close()


